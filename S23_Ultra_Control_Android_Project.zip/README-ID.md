# S23 Ultra Control

Aplikasi Android contoh untuk Galaxy S23 Ultra (Snapdragon 8 Gen 2), tanpa root.

## Fitur
- Membaca status termal melalui Android PowerManager API.
- Membaca perkiraan thermal headroom jika firmware menyediakan sensor/API.
- Membaca suhu baterai dari broadcast Android.
- Opsional: memakai Shizuku untuk meminta Android Game Mode `performance` bagi paket game yang dimasukkan.

## Batasan penting
Aplikasi ini TIDAK menonaktifkan thermal throttling, tidak mengubah batas suhu Samsung, tidak menulis ke `/sys`, tidak mengubah governor CPU/GPU, dan tidak menonaktifkan proteksi baterai/termal. Android/Samsung mengendalikan proteksi tersebut. Game Mode performance hanya permintaan ke layanan Game Mode Android dan dapat tidak didukung/diabaikan oleh firmware Samsung.

## Cara build APK
1. Buka folder proyek ini di Android Studio versi terbaru.
2. Biarkan Gradle menyinkronkan dependensi (perlu internet untuk plugin Android dan Shizuku API).
3. Pilih Build > Build APK(s).
4. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.
5. Pindahkan APK ke S23 Ultra dan izinkan instalasi dari sumber tersebut.

## Cara menggunakan Shizuku
1. Instal aplikasi Shizuku resmi dari sumber resminya: https://shizuku.rikka.app/
2. Aktifkan Developer options dan Wireless debugging.
3. Mulai Shizuku menggunakan instruksi pada aplikasi Shizuku (Android 11+ umumnya melalui Wireless debugging atau pairing).
4. Buka S23 Ultra Control, tekan CONNECT / REQUEST SHIZUKU dan berikan izin.
5. Masukkan package name game lalu tekan tombol Game Mode. Perintah dapat ditolak atau tidak didukung oleh firmware.

## Kompatibilitas
- minSdk 29 (Android 10), targetSdk 35.
- Java 17, Android Gradle Plugin 8.6.1.
- Source menggunakan Shizuku API 13.1.5.
