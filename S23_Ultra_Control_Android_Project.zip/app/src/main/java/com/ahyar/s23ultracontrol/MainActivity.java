package com.ahyar.s23ultracontrol;

import android.app.Activity;
import android.os.Bundle;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(7, 10, 16);
    private final int PANEL = Color.rgb(17, 24, 35);
    private final int CYAN = Color.rgb(0, 229, 255);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView thermalText, batteryText, headroomText, shizukuText, logText;
    private EditText packageInput;
    private PowerManager powerManager;
    private static final int SHIZUKU_REQ = 2301;

    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            updateMetrics();
            handler.postDelayed(this, 3000);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        powerManager = (PowerManager)getSystemService(POWER_SERVICE);
        buildUi();
        updateShizukuStatus();
        handler.post(refresh);
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(18, 14, 18, 14);
        l.setBackgroundColor(PANEL);
        return l;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 24, 18, 24);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("S23 ULTRA CONTROL", 25, CYAN, true);
        root.addView(title);
        TextView subtitle = text("SNAPDRAGON 8 GEN 2  •  SAFE PERFORMANCE PANEL", 10,
                Color.LTGRAY, true);
        subtitle.setPadding(0, 5, 0, 20); root.addView(subtitle);

        root.addView(sectionLabel("LIVE DEVICE TELEMETRY"));
        LinearLayout metrics = column();
        thermalText = text("THERMAL STATUS   —", 17, Color.WHITE, true);
        batteryText = text("BATTERY TEMP   —", 16, Color.LTGRAY, false);
        headroomText = text("THERMAL HEADROOM   —", 15, CYAN, true);
        metrics.addView(thermalText); metrics.addView(gap());
        metrics.addView(batteryText); metrics.addView(gap());
        metrics.addView(headroomText);
        root.addView(metrics);

        root.addView(sectionLabel("ACCESS BRIDGE"));
        LinearLayout bridge = column();
        shizukuText = text("Shizuku: checking…", 15, Color.WHITE, true);
        bridge.addView(shizukuText);
        Button permission = button("CONNECT / REQUEST SHIZUKU");
        permission.setOnClickListener(v -> connectShizuku());
        bridge.addView(permission);
        root.addView(bridge);

        root.addView(sectionLabel("GAME MODE (OPTIONAL)"));
        LinearLayout game = column();
        TextView note = text("Enter the package name of a game. This requests Android's supported Game Mode performance profile where the firmware allows it. It does NOT disable thermal protection.", 13, Color.LTGRAY, false);
        game.addView(note);
        packageInput = new EditText(this);
        packageInput.setSingleLine(true);
        packageInput.setHint("e.g. com.example.game");
        packageInput.setHintTextColor(Color.GRAY);
        packageInput.setTextColor(Color.WHITE);
        packageInput.setBackgroundTintList(android.content.res.ColorStateList.valueOf(CYAN));
        game.addView(packageInput);
        Button apply = button("REQUEST PERFORMANCE GAME MODE");
        apply.setOnClickListener(v -> applyGameMode());
        game.addView(apply);
        root.addView(game);

        root.addView(sectionLabel("SYSTEM OUTPUT"));
        LinearLayout output = column();
        logText = text("Ready. Thermal protection remains enabled.", 12, Color.LTGRAY, false);
        output.addView(logText);
        root.addView(output);

        TextView footer = text("No root • Shizuku optional • No thermal-limit bypass", 11,
                Color.GRAY, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, 22, 0, 8); root.addView(footer);
    }

    private TextView sectionLabel(String s) {
        TextView t = text(s, 11, CYAN, true);
        t.setPadding(2, 20, 0, 8); return t;
    }
    private View gap() { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1, 10)); return v; }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.BLACK);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(CYAN));
        return b;
    }

    private void updateMetrics() {
        if (Build.VERSION.SDK_INT >= 29) {
            int s = powerManager.getCurrentThermalStatus();
            String[] names = {"NORMAL", "LIGHT", "MODERATE", "SEVERE", "CRITICAL", "EMERGENCY", "SHUTDOWN"};
            String name = (s >= 0 && s < names.length) ? names[s] : "UNKNOWN";
            thermalText.setText("THERMAL STATUS   " + name);
            thermalText.setTextColor(s >= 3 ? Color.RED : (s >= 1 ? 0xFFFFB74D : CYAN));
            try {
                float h = powerManager.getThermalHeadroom(0);
                headroomText.setText(Float.isNaN(h) ? "THERMAL HEADROOM   Not exposed by firmware" :
                        String.format(java.util.Locale.US, "THERMAL HEADROOM   %.2f / 1.00", h));
            } catch (Throwable e) {
                headroomText.setText("THERMAL HEADROOM   Not supported");
            }
        } else {
            thermalText.setText("THERMAL STATUS   API NOT AVAILABLE");
        }
        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery != null) {
            int temp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            batteryText.setText(temp >= 0 ? String.format(java.util.Locale.US,
                    "BATTERY TEMP   %.1f °C", temp / 10f) : "BATTERY TEMP   Not available");
        }
    }

    private void updateShizukuStatus() {
        try {
            boolean running = Shizuku.pingBinder();
            int perm = running ? Shizuku.checkSelfPermission() : -1;
            shizukuText.setText(!running ? "Shizuku: NOT RUNNING" :
                    (perm == android.content.pm.PackageManager.PERMISSION_GRANTED ?
                            "Shizuku: CONNECTED / PERMISSION GRANTED" : "Shizuku: RUNNING / PERMISSION NEEDED"));
        } catch (Throwable e) {
            shizukuText.setText("Shizuku: not connected (normal mode still works)");
        }
    }

    private void connectShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                log("Install and start Shizuku, then return here.");
                updateShizukuStatus(); return;
            }
            if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                log("Shizuku permission already granted.");
            } else {
                Shizuku.requestPermission(SHIZUKU_REQ);
                log("Permission request sent to Shizuku.");
            }
            updateShizukuStatus();
        } catch (Throwable e) { log("Shizuku unavailable: " + e.getMessage()); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        updateShizukuStatus();
    }

    private void applyGameMode() {
        String pkg = packageInput.getText().toString().trim();
        if (pkg.isEmpty() || !pkg.matches("[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+")) {
            log("Enter a valid game package name first."); return;
        }
        try {
            if (!Shizuku.pingBinder() ||
                Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                log("Connect Shizuku and grant permission first."); return;
            }
            worker.execute(() -> {
                String result = runShell(new String[]{"sh", "-c", "cmd game mode performance " + pkg});
                runOnUiThread(() -> log(result.isEmpty() ?
                        "Command sent. Firmware may ignore unsupported Game Mode requests." : result));
            });
        } catch (Throwable e) { log("Could not run command: " + e.getMessage()); }
    }

    private String runShell(String[] command) {
        StringBuilder out = new StringBuilder();
        try {
            Process p = Shizuku.newProcess(command, null, null);
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line; while ((line = r.readLine()) != null) out.append(line).append('\n');
            BufferedReader er = new BufferedReader(new InputStreamReader(p.getErrorStream()));
            while ((line = er.readLine()) != null) out.append(line).append('\n');
            p.waitFor();
        } catch (Throwable e) { out.append(e.getClass().getSimpleName()).append(": ").append(e.getMessage()); }
        return out.toString().trim();
    }

    private void log(String s) { logText.setText(s); }

    @Override protected void onDestroy() {
        handler.removeCallbacks(refresh);
        worker.shutdownNow();
        super.onDestroy();
    }
}
